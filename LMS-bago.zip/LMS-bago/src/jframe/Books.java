/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package jframe;

import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
/**
 *
 * @author Admin
 */
public class Books extends javax.swing.JFrame {
    public static int bookCount = 0;
    /**
     * Creates new form Books
     */
    public Books() {
        initComponents();
        jTable1.addMouseListener(new java.awt.event.MouseAdapter() {
    public void mousePressed(java.awt.event.MouseEvent evt) {
        if (evt.isPopupTrigger()) {
            showUpdateDialog(evt);
        }
    }

    public void mouseReleased(java.awt.event.MouseEvent evt) {
        if (evt.isPopupTrigger()) {
            showUpdateDialog(evt);
        }
    }
});
        loadBooksFromDatabase();
        
         
    }
    private void showUpdateDialog(java.awt.event.MouseEvent evt) {
    int row = jTable1.rowAtPoint(evt.getPoint());
int column = jTable1.columnAtPoint(evt.getPoint());

if (row < 0 || column < 0) return;

jTable1.setRowSelectionInterval(row, row);
jTable1.setColumnSelectionInterval(column, column);

DefaultTableModel model = (DefaultTableModel) jTable1.getModel();
String originalTitle = model.getValueAt(row, 0).toString();

// 🔒 Check if the book is borrowed, but allow editing Quantity
if (isBookBorrowed(originalTitle) && !jTable1.getColumnName(column).equals("Quantity")) {
    JOptionPane.showMessageDialog(this,
        "This book is currently borrowed and cannot be edited.",
        "Edit Restricted",
        JOptionPane.WARNING_MESSAGE);
    return; // Stop editing other columns
}

String oldValue = model.getValueAt(row, column).toString();
String columnName = jTable1.getColumnName(column);

String newValue = null;

// 🟢 Use JComboBox when editing Category
if (columnName.equals("Category")) {
    javax.swing.JComboBox<String> categoryBox = new javax.swing.JComboBox<>();

    // Copy all categories from your main category JComboBox
    for (int i = 0; i < category.getItemCount(); i++) {
        categoryBox.addItem(category.getItemAt(i));
    }

    // Preselect the current category
    categoryBox.setSelectedItem(oldValue);

    int result = JOptionPane.showConfirmDialog(
        this,
        categoryBox,
        "Select new category",
        JOptionPane.OK_CANCEL_OPTION,
        JOptionPane.PLAIN_MESSAGE
    );

    if (result == JOptionPane.OK_OPTION) {
        newValue = (String) categoryBox.getSelectedItem();
    } else {
        return; // Cancel pressed
    }
} else {
    // Default input for other columns
    newValue = JOptionPane.showInputDialog(this, "Enter new value for " + columnName + ":", oldValue);
    if (newValue == null || newValue.trim().isEmpty()) {
        return;
    }
    newValue = newValue.trim();
}

// Validate Quantity
if (columnName.equals("Quantity")) {
    try {
        Integer.parseInt(newValue);
    } catch (NumberFormatException e) {
        JOptionPane.showMessageDialog(this, "Quantity must be a valid number.", "Invalid Input", JOptionPane.ERROR_MESSAGE);
        return;
    }
}

// Validate Category
if (columnName.equals("Category")) {
    boolean isValid = false;
    for (int i = 0; i < category.getItemCount(); i++) {
        if (category.getItemAt(i).equalsIgnoreCase(newValue)) {
            newValue = category.getItemAt(i); // Normalize case
            isValid = true;
            break;
        }
    }
    if (!isValid) {
        JOptionPane.showMessageDialog(this, "Please input a proper category from the list.", "Invalid Category", JOptionPane.ERROR_MESSAGE);
        return;
    }
}

// Get original identifying values
String originalAuthor = model.getValueAt(row, 1).toString();
String originalCategory = model.getValueAt(row, 2).toString();

try (Connection con = DBConnection.getConnection()) {
    String dbColumn = columnName.equals("Book Title") ? "title"
                    : columnName.equals("Author") ? "author"
                    : columnName.equals("Category") ? "category"
                    : columnName.equals("Quantity") ? "quantity"
                    : null;

    if (dbColumn == null) return;

    String sql = "UPDATE books1 SET " + dbColumn + "=? WHERE title=? AND author=? AND category=?";
    java.sql.PreparedStatement ps = con.prepareStatement(sql);

    if (dbColumn.equals("quantity")) {
        ps.setInt(1, Integer.parseInt(newValue));
    } else {
        ps.setString(1, newValue);
    }

    ps.setString(2, originalTitle);
    ps.setString(3, originalAuthor);
    ps.setString(4, originalCategory);

    int rowsAffected = ps.executeUpdate();
    if (rowsAffected > 0) {
        JOptionPane.showMessageDialog(this, columnName + " updated successfully!");
    } else {
        JOptionPane.showMessageDialog(this, "Update failed. Book not found.");
    }

    loadBooksFromDatabase(); // Refresh table

} catch (Exception e) {
    e.printStackTrace();
    JOptionPane.showMessageDialog(this, "Database error while updating.");
    }
}
    
    private void loadBooksFromDatabase() {
    DefaultTableModel model = (DefaultTableModel) jTable1.getModel();
    model.setRowCount(0); // clear table

    try (Connection con = DBConnection.getConnection();
         java.sql.Statement st = con.createStatement();
         java.sql.ResultSet rs = st.executeQuery("SELECT * FROM books1")) {

        while (rs.next()) {
            model.addRow(new Object[]{
                rs.getString("title"),
                rs.getString("author"),
                rs.getString("category"),
                rs.getInt("quantity")
            });
        }

    } catch (Exception e) {
        e.printStackTrace();
        JOptionPane.showMessageDialog(this, "Error loading books from database.");
    }
}
    private boolean isBookBorrowed(String title) {
    boolean borrowed = false;
    try (Connection con = DBConnection.getConnection()) {
        String sql = "SELECT COUNT(*) FROM borrowed_books3 WHERE book_title = ?";
        PreparedStatement ps = con.prepareStatement(sql);
        ps.setString(1, title);
        java.sql.ResultSet rs = ps.executeQuery();
        if (rs.next()) {
            borrowed = rs.getInt(1) > 0;
        }
    } catch (Exception e) {
        e.printStackTrace();
    }
    return borrowed;
}
    

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        title = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        author = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        quantity = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        add = new javax.swing.JButton();
        category = new javax.swing.JComboBox<>();
        jPanel4 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jLabel1 = new javax.swing.JLabel();
        update = new javax.swing.JButton();
        remove = new javax.swing.JButton();
        rewind = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(153, 153, 153));

        jLabel2.setFont(new java.awt.Font("Segoe UI Black", 0, 14)); // NOI18N
        jLabel2.setText("Book Title");

        title.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                titleActionPerformed(evt);
            }
        });

        jLabel3.setFont(new java.awt.Font("Segoe UI Black", 0, 24)); // NOI18N
        jLabel3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/AddNewBookIcons/AddNewBookIcons/icons8_Books_52px_1.png"))); // NOI18N
        jLabel3.setText("ADD BOOKS");

        author.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                authorActionPerformed(evt);
            }
        });

        jLabel4.setFont(new java.awt.Font("Segoe UI Black", 0, 14)); // NOI18N
        jLabel4.setText("Author");

        jLabel5.setFont(new java.awt.Font("Segoe UI Black", 0, 14)); // NOI18N
        jLabel5.setText("Category");

        quantity.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                quantityActionPerformed(evt);
            }
        });

        jLabel6.setFont(new java.awt.Font("Segoe UI Black", 0, 14)); // NOI18N
        jLabel6.setText("Quantity");

        add.setFont(new java.awt.Font("Segoe UI Black", 1, 14)); // NOI18N
        add.setText("ADD");
        add.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                addActionPerformed(evt);
            }
        });

        category.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] {
            "Fiction",
            "Non-Fiction",
            "Science",
            "Mathematics",
            "Technology",
            "Engineering",
            "History",
            "Biography",
            "Philosophy",
            "Religion",
            "Psychology",
            "Health",
            "Travel",
            "Children's",
            "Young Adult",
            "Poetry",
            "Comics",
            "Mystery",
            "Horror",
            "Romance"
        }));

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap(32, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel3)
                        .addGap(30, 30, 30))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                        .addComponent(quantity, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 258, Short.MAX_VALUE)
                        .addComponent(jLabel6, javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(jLabel5, javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(jLabel4, javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(jLabel2, javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(title, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 258, Short.MAX_VALUE)
                        .addComponent(author, javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(category, javax.swing.GroupLayout.Alignment.LEADING, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addComponent(add, javax.swing.GroupLayout.PREFERRED_SIZE, 123, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(64, 64, 64)))
                .addGap(21, 21, 21))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(43, 43, 43)
                .addComponent(jLabel3)
                .addGap(29, 29, 29)
                .addComponent(jLabel2)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(title, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jLabel4)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(author, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jLabel5)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(category, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel6)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(quantity, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(42, 42, 42)
                .addComponent(add, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(63, Short.MAX_VALUE))
        );

        jPanel4.setBackground(new java.awt.Color(153, 255, 153));

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Book Title", "Author", "Category", "Quantity"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.Integer.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jTable1.setColumnSelectionAllowed(true);
        jScrollPane1.setViewportView(jTable1);
        jTable1.getColumnModel().getSelectionModel().setSelectionMode(javax.swing.ListSelectionModel.SINGLE_SELECTION);
        if (jTable1.getColumnModel().getColumnCount() > 0) {
            jTable1.getColumnModel().getColumn(0).setResizable(false);
            jTable1.getColumnModel().getColumn(1).setResizable(false);
            jTable1.getColumnModel().getColumn(2).setResizable(false);
            jTable1.getColumnModel().getColumn(3).setResizable(false);
        }

        jLabel1.setFont(new java.awt.Font("Segoe UI Black", 0, 36)); // NOI18N
        jLabel1.setText("BOOKS");

        update.setBackground(new java.awt.Color(204, 204, 255));
        update.setFont(new java.awt.Font("Segoe UI Black", 1, 14)); // NOI18N
        update.setText("UPDATE");
        update.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                updateActionPerformed(evt);
            }
        });

        remove.setBackground(new java.awt.Color(255, 51, 51));
        remove.setFont(new java.awt.Font("Segoe UI Black", 1, 14)); // NOI18N
        remove.setText("ARCHIVE");
        remove.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                removeActionPerformed(evt);
            }
        });

        rewind.setBackground(new java.awt.Color(153, 255, 153));
        rewind.setForeground(new java.awt.Color(255, 255, 255));
        rewind.setIcon(new javax.swing.ImageIcon(getClass().getResource("/adminIcons/adminIcons/icons8_Exit_26px.png"))); // NOI18N
        rewind.setBorder(null);
        rewind.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rewindActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 624, Short.MAX_VALUE)
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addGap(9, 9, 9)
                        .addComponent(rewind, javax.swing.GroupLayout.PREFERRED_SIZE, 46, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jLabel1)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(update)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(remove)
                        .addGap(6, 6, 6)))
                .addContainerGap())
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel4Layout.createSequentialGroup()
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(remove, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(update, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel1)))
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(rewind, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(12, 12, 12))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void titleActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_titleActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_titleActionPerformed

    private void authorActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_authorActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_authorActionPerformed

    private void quantityActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_quantityActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_quantityActionPerformed

    private void addActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_addActionPerformed
    String bookTitle = title.getText().trim();
    String bookAuthor = author.getText().trim();
    String bookCategory = (String) category.getSelectedItem();
    String quantityStr = quantity.getText().trim();

    if (bookTitle.isEmpty() || bookAuthor.isEmpty() || quantityStr.isEmpty()) {
        JOptionPane.showMessageDialog(this, "Please fill all fields.", "Error", JOptionPane.ERROR_MESSAGE);
        return;
    }

    int qty;
    try {
        qty = Integer.parseInt(quantityStr);
        if (qty < 0) throw new NumberFormatException();
    } catch (NumberFormatException e) {
        JOptionPane.showMessageDialog(this, "Quantity must be a positive number.", "Error", JOptionPane.ERROR_MESSAGE);
        return;
    }

    try (Connection con = DBConnection.getConnection()) {
        String checkSql = "SELECT * FROM books1 WHERE title=? AND author=? AND category=?";
        java.sql.PreparedStatement checkStmt = con.prepareStatement(checkSql);
        checkStmt.setString(1, bookTitle);
        checkStmt.setString(2, bookAuthor);
        checkStmt.setString(3, bookCategory);
        java.sql.ResultSet rs = checkStmt.executeQuery();

        if (rs.next()) {
            // Book exists → update quantity
            int currentQty = rs.getInt("quantity");
            int newQty = currentQty + qty;
            java.sql.PreparedStatement updateStmt =
                con.prepareStatement("UPDATE books1 SET quantity=? WHERE id=?");
            updateStmt.setInt(1, newQty);
            updateStmt.setInt(2, rs.getInt("id"));
            updateStmt.executeUpdate();
            JOptionPane.showMessageDialog(this, "Quantity updated successfully!");
        } else {
            // New book → insert
            String insertSql = "INSERT INTO books1 (title, author, category, quantity) VALUES (?, ?, ?, ?)";
            java.sql.PreparedStatement ps = con.prepareStatement(insertSql);
            ps.setString(1, bookTitle);
            ps.setString(2, bookAuthor);
            ps.setString(3, bookCategory);
            ps.setInt(4, qty);
            ps.executeUpdate();
            JOptionPane.showMessageDialog(this, "New book added successfully!");
        }

        loadBooksFromDatabase(); // refresh table
        title.setText(""); author.setText(""); quantity.setText("");
        category.setSelectedIndex(0);

    } catch (Exception e) {
        e.printStackTrace();
        JOptionPane.showMessageDialog(this, "Database error while adding book.");
    }
    }//GEN-LAST:event_addActionPerformed

    private void updateActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_updateActionPerformed
    int selectedRow = jTable1.getSelectedRow();
    int selectedColumn = jTable1.getSelectedColumn();

    if (selectedRow < 0 || selectedColumn < 0) {
        JOptionPane.showMessageDialog(this, "Please select a cell to update.", "No Selection", JOptionPane.WARNING_MESSAGE);
        return;
    }

    DefaultTableModel model = (DefaultTableModel) jTable1.getModel();
    String originalTitle = model.getValueAt(selectedRow, 0).toString();
    String originalAuthor = model.getValueAt(selectedRow, 1).toString();
    String originalCategory = model.getValueAt(selectedRow, 2).toString();
    String oldValue = model.getValueAt(selectedRow, selectedColumn).toString();
    String columnName = jTable1.getColumnName(selectedColumn);

    // 🔒 Check if book is borrowed, but allow updating Quantity
    if (isBookBorrowed(originalTitle) && !columnName.equals("Quantity")) {
        JOptionPane.showMessageDialog(this,
            "This book is currently borrowed and cannot be updated.",
            "Update Restricted",
            JOptionPane.WARNING_MESSAGE);
        return;
    }

    String newValue = null;

    // ✅ If updating Category, show JComboBox dropdown
    if (columnName.equals("Category")) {
        javax.swing.JComboBox<String> categoryBox = new javax.swing.JComboBox<>();
        for (int i = 0; i < category.getItemCount(); i++) {
            categoryBox.addItem(category.getItemAt(i));
        }
        categoryBox.setSelectedItem(oldValue);

        int result = JOptionPane.showConfirmDialog(
            this,
            categoryBox,
            "Select new category",
            JOptionPane.OK_CANCEL_OPTION,
            JOptionPane.PLAIN_MESSAGE
        );

        if (result == JOptionPane.OK_OPTION) {
            newValue = (String) categoryBox.getSelectedItem();
        } else {
            JOptionPane.showMessageDialog(this, "Update cancelled.");
            return;
        }

    } else {
        newValue = JOptionPane.showInputDialog(this, "Enter new value for " + columnName + ":", oldValue);
        if (newValue == null || newValue.trim().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Update cancelled or empty value.");
            return;
        }
        newValue = newValue.trim();
    }

    // Validate quantity
    if (columnName.equals("Quantity")) {
        try {
            Integer.parseInt(newValue);
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Quantity must be a valid number.", "Invalid Input", JOptionPane.ERROR_MESSAGE);
            return;
        }
    }

    // Perform database update
    try (Connection con = DBConnection.getConnection()) {
        String dbColumn = columnName.equals("Book Title") ? "title"
                        : columnName.equals("Author") ? "author"
                        : columnName.equals("Category") ? "category"
                        : columnName.equals("Quantity") ? "quantity"
                        : null;

        if (dbColumn == null) {
            JOptionPane.showMessageDialog(this, "Invalid column selected.");
            return;
        }

        String sql = "UPDATE books1 SET " + dbColumn + "=? WHERE title=? AND author=? AND category=?";
        java.sql.PreparedStatement ps = con.prepareStatement(sql);

        if (dbColumn.equals("quantity")) {
            ps.setInt(1, Integer.parseInt(newValue));
        } else {
            ps.setString(1, newValue);
        }

        ps.setString(2, originalTitle);
        ps.setString(3, originalAuthor);
        ps.setString(4, originalCategory);

        int rowsAffected = ps.executeUpdate();
        if (rowsAffected > 0) {
            JOptionPane.showMessageDialog(this, columnName + " updated successfully!");
        } else {
            JOptionPane.showMessageDialog(this, "Failed to update. Book not found.");
        }

        loadBooksFromDatabase(); // Refresh table

    } catch (Exception e) {
        e.printStackTrace();
        JOptionPane.showMessageDialog(this, "Database error while updating.");

    }
    }//GEN-LAST:event_updateActionPerformed

    private void removeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_removeActionPerformed
    int selectedRow = jTable1.getSelectedRow();
    if (selectedRow < 0) {
        JOptionPane.showMessageDialog(this, "Please select a book to archive.");
        return;
    }

    DefaultTableModel model = (DefaultTableModel) jTable1.getModel();
    String bookTitle = model.getValueAt(selectedRow, 0).toString();
    String bookAuthor = model.getValueAt(selectedRow, 1).toString();
    String bookCategory = model.getValueAt(selectedRow, 2).toString();
    int bookQuantity = Integer.parseInt(model.getValueAt(selectedRow, 3).toString());

    try (Connection con = DBConnection.getConnection()) {
        // Step 1: Check if the book is currently borrowed
        String checkBorrowedSQL = "SELECT COUNT(*) FROM borrowed_books3 WHERE book_title = ?";
        PreparedStatement psCheck = con.prepareStatement(checkBorrowedSQL);
        psCheck.setString(1, bookTitle);

        ResultSet rsCheck = psCheck.executeQuery();
        if (rsCheck.next() && rsCheck.getInt(1) > 0) {
            JOptionPane.showMessageDialog(this, "This book is currently borrowed and cannot be archived.");
            return; // Exit the method without archiving
        }

        // Step 2: Insert into archive_books
        String insertSQL = "INSERT INTO archive_books (title, author, category, quantity) VALUES (?, ?, ?, ?)";
        PreparedStatement psInsert = con.prepareStatement(insertSQL);
        psInsert.setString(1, bookTitle);
        psInsert.setString(2, bookAuthor);
        psInsert.setString(3, bookCategory);
        psInsert.setInt(4, bookQuantity);
        psInsert.executeUpdate();

        // Step 3: Delete from books1
        String deleteSQL = "DELETE FROM books1 WHERE title = ? AND author = ? AND category = ?";
        PreparedStatement psDelete = con.prepareStatement(deleteSQL);
        psDelete.setString(1, bookTitle);
        psDelete.setString(2, bookAuthor);
        psDelete.setString(3, bookCategory);
        psDelete.executeUpdate();

        JOptionPane.showMessageDialog(this, "Book archived successfully!");
        loadBooksFromDatabase();

    } catch (Exception e) {
        e.printStackTrace();
        JOptionPane.showMessageDialog(this, "Error archiving book.");
    }

    }//GEN-LAST:event_removeActionPerformed

    private void rewindActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rewindActionPerformed
        setVisible(false);
        new Home().setVisible(true);
    }//GEN-LAST:event_rewindActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Books.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Books.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Books.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Books.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Books().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton add;
    private javax.swing.JTextField author;
    private javax.swing.JComboBox<String> category;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTable1;
    private javax.swing.JTextField quantity;
    private javax.swing.JButton remove;
    private javax.swing.JButton rewind;
    private javax.swing.JTextField title;
    private javax.swing.JButton update;
    // End of variables declaration//GEN-END:variables
}
