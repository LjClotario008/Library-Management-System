/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package jframe;

import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableRowSorter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JPopupMenu;
import javax.swing.JMenuItem;
/**
 *
 * @author Admin
 */
public class Students extends javax.swing.JFrame {
    public static int studentCount = 0;
    public static void clearStudentList() {
}
    private DefaultTableModel studentModel;
    private TableRowSorter<DefaultTableModel> sorter;
    /**
     * Creates new form Students
     */
    public Students() {
        initComponents();
        clearStudentList();
        studentTableSetup();
        loadStudentsFromDatabase();
        
        JPopupMenu popupMenu = new JPopupMenu();
        JMenuItem updateItem = new JMenuItem("Edit / Update Record");

// when user clicks the popup item
updateItem.addActionListener(e -> {
    int row = JTable1.getSelectedRow();
    int col = JTable1.getSelectedColumn();

    if (row >= 0 && col >= 0) {
        java.awt.event.MouseEvent fakeEvent = new java.awt.event.MouseEvent(
            JTable1, 0, 0, 0, 0, 0, 1, false
        );
        handleRightClickUpdate(fakeEvent);
    }
});

popupMenu.add(updateItem);

// show popup when user right-clicks
JTable1.addMouseListener(new java.awt.event.MouseAdapter() {
    @Override
    public void mousePressed(java.awt.event.MouseEvent evt) {
        showPopup(evt);
    }

    @Override
    public void mouseReleased(java.awt.event.MouseEvent evt) {
        showPopup(evt);
    }

    private void showPopup(java.awt.event.MouseEvent evt) {
        if (evt.isPopupTrigger()) {
            int row = JTable1.rowAtPoint(evt.getPoint());
            int col = JTable1.columnAtPoint(evt.getPoint());
            if (row >= 0 && col >= 0) {
                JTable1.setRowSelectionInterval(row, row);
                JTable1.setColumnSelectionInterval(col, col);
                popupMenu.show(evt.getComponent(), evt.getX(), evt.getY());
            }
        }
    }
});
    }
    
    private void handleRightClickUpdate(java.awt.event.MouseEvent evt) {
    int selectedRow = JTable1.getSelectedRow();
int selectedColumn = JTable1.getSelectedColumn();

if (selectedRow == -1 || selectedColumn == -1) {
    JOptionPane.showMessageDialog(this, "Please select a cell to update.");
    return;
}

String columnName = JTable1.getColumnName(selectedColumn);
String oldValue = JTable1.getValueAt(selectedRow, selectedColumn).toString();
String studentId = JTable1.getValueAt(selectedRow, 0).toString();
String firstName = JTable1.getValueAt(selectedRow, 1).toString();
String lastName = JTable1.getValueAt(selectedRow, 2).toString();

// 🧩 Prompt for new value
String newValue = null;

if (columnName.equals("Grade Level")) {
    String[] grades = {"Grade 7", "Grade 8", "Grade 9", "Grade 10", "Grade 11", "Grade 12"};
    newValue = (String) JOptionPane.showInputDialog(
        this,
        "Select new Grade Level:",
        "Update Grade Level",
        JOptionPane.PLAIN_MESSAGE,
        null,
        grades,
        oldValue
    );
} else {
    newValue = JOptionPane.showInputDialog(
        this,
        "Enter new value for " + columnName + ":",
        oldValue
    );
}

if (newValue == null) {
    JOptionPane.showMessageDialog(this, "Update cancelled.");
    return;
}

newValue = newValue.trim();
if (newValue.isEmpty()) {
    JOptionPane.showMessageDialog(this, "Value cannot be empty.");
    return;
}

// Map JTable column to SQL column
String sqlColumn = switch (columnName) {
    case "Student ID" -> "student_id";
    case "First Name" -> "first_name";
    case "Last Name" -> "last_name";
    case "Grade Level" -> "grade_level";
    case "Contact Number" -> "contact";
    case "Email Address" -> "email_address";
    case "Address" -> "address";
    default -> null;
};

if (sqlColumn == null) {
    JOptionPane.showMessageDialog(this, "This column cannot be updated.");
    return;
}

// 🧠 Format name fields
if (sqlColumn.equals("first_name") || sqlColumn.equals("last_name")) {
    newValue = capitalizeWords(newValue);
}

// ✅ Validate student_id format
if (sqlColumn.equals("student_id") && !newValue.matches("\\d{12}")) {
    JOptionPane.showMessageDialog(this, "Student ID must be exactly 12 digits.");
    return;
}

// ✅ Validate email format
if (sqlColumn.equals("email_address")) {
    if (!newValue.contains("@")) {
        JOptionPane.showMessageDialog(this,
            "Invalid email address. It must contain '@'.",
            "Invalid Email",
            JOptionPane.WARNING_MESSAGE);
        return;
    }
}

// ✅ Validate contact number format
if (sqlColumn.equals("contact")) {
    if (!newValue.matches("\\d{11}")) {
        JOptionPane.showMessageDialog(this,
            "Invalid contact number. It must contain exactly 11 digits.",
            "Invalid Contact",
            JOptionPane.WARNING_MESSAGE);
        return;
    }
}

try (Connection con = DBConnection.getConnection()) {
    // ✅ Prevent duplicate student_id
    if (sqlColumn.equals("student_id")) {
        PreparedStatement check = con.prepareStatement("SELECT * FROM students2 WHERE student_id = ?");
        check.setString(1, newValue);
        ResultSet rs = check.executeQuery();
        if (rs.next()) {
            JOptionPane.showMessageDialog(this, "Student already registered with this ID!");
            return;
        }
    }

    // ✅ Perform the update
    String sql = "UPDATE students2 SET " + sqlColumn + " = ? WHERE student_id = ?";
    PreparedStatement ps = con.prepareStatement(sql);
    ps.setString(1, newValue);
    ps.setString(2, studentId);
    int updated = ps.executeUpdate();

    if (updated > 0) {
        JOptionPane.showMessageDialog(this, columnName + " updated successfully!");
        loadStudentsFromDatabase();  // Refresh the table
    } else {
        JOptionPane.showMessageDialog(this, "Update failed. Student not found.");
    }

} catch (SQLException e) {
    e.printStackTrace();
    JOptionPane.showMessageDialog(this, "Database error while updating student:\n" + e.getMessage());
    }
}
    private String capitalizeWords(String str) {
    String[] words = str.toLowerCase().split("\\s+");
    StringBuilder sb = new StringBuilder();
    for (String word : words) {
        if (word.length() > 0) {
            sb.append(Character.toUpperCase(word.charAt(0)))
              .append(word.substring(1))
              .append(" ");
        }
    }
    return sb.toString().trim();
}
    private void loadStudentsFromDatabase() {
    studentModel.setRowCount(0); // clear table first
    try (Connection con = DBConnection.getConnection();
         PreparedStatement ps = con.prepareStatement("SELECT * FROM students2");
         ResultSet rs = ps.executeQuery()) {

        while (rs.next()) {
            studentModel.addRow(new Object[]{
                rs.getString("student_id"),
                rs.getString("first_name"),
                rs.getString("last_name"),
                rs.getString("grade_level"),
                rs.getString("email_address"),
                rs.getString("contact"),
                rs.getString("address")
            });
        }

        studentCount = studentModel.getRowCount();

    } catch (Exception e) {
        e.printStackTrace();
        JOptionPane.showMessageDialog(this, "Error loading students from database.");
    }
}
    
    private void studentTableSetup() {
    // Table Model
     studentModel = new DefaultTableModel(
    new String[] {"Student ID", "First Name", "Last Name", "Grade Level", "Email Address", "Contact Number", "Address"}, 
    0
        ) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;  // all cells non-editable
            }
        };

        JTable1.setModel(studentModel);

        // Optional safeguard: disable default cell editors
        JTable1.setDefaultEditor(Object.class, null);

        // Setup sorter
        sorter = new TableRowSorter<>(studentModel);
        JTable1.setRowSorter(sorter);

        // Populate grade level combo box
        gradelevel.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] {
            "Grade 7", "Grade 8", "Grade 9", "Grade 10", "Grade 11", "Grade 12"
        }));
    }
    
    
    

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel3 = new javax.swing.JPanel();
        jPanel1 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        studentID = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        fname = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        lname = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        add = new javax.swing.JButton();
        contactnumber = new javax.swing.JTextField();
        emailaddress = new javax.swing.JTextField();
        adress = new javax.swing.JTextField();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        gradelevel = new javax.swing.JComboBox<>();
        jPanel4 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        JTable1 = new javax.swing.JTable();
        jLabel1 = new javax.swing.JLabel();
        update = new javax.swing.JButton();
        remove = new javax.swing.JButton();
        rewind = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );

        jPanel1.setBackground(new java.awt.Color(153, 153, 153));

        jLabel2.setFont(new java.awt.Font("Segoe UI Black", 0, 14)); // NOI18N
        jLabel2.setText("Student ID");

        studentID.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                studentIDActionPerformed(evt);
            }
        });

        jLabel3.setFont(new java.awt.Font("Segoe UI Black", 0, 24)); // NOI18N
        jLabel3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/adminIcons/adminIcons/icons8_People_50px.png"))); // NOI18N
        jLabel3.setText("ADD STUDENTS");

        fname.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                fnameActionPerformed(evt);
            }
        });

        jLabel4.setFont(new java.awt.Font("Segoe UI Black", 0, 14)); // NOI18N
        jLabel4.setText("First Name");

        lname.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                lnameActionPerformed(evt);
            }
        });

        jLabel5.setFont(new java.awt.Font("Segoe UI Black", 0, 14)); // NOI18N
        jLabel5.setText("Last Name");

        jLabel6.setFont(new java.awt.Font("Segoe UI Black", 0, 14)); // NOI18N
        jLabel6.setText("Grade Level");

        add.setFont(new java.awt.Font("Segoe UI Black", 1, 14)); // NOI18N
        add.setText("ADD");
        add.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                addActionPerformed(evt);
            }
        });

        contactnumber.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                contactnumberActionPerformed(evt);
            }
        });

        emailaddress.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                emailaddressActionPerformed(evt);
            }
        });

        adress.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                adressActionPerformed(evt);
            }
        });

        jLabel7.setFont(new java.awt.Font("Segoe UI Black", 0, 14)); // NOI18N
        jLabel7.setText("Email Address");

        jLabel8.setFont(new java.awt.Font("Segoe UI Black", 0, 14)); // NOI18N
        jLabel8.setText("Contact Number");

        jLabel9.setFont(new java.awt.Font("Segoe UI Black", 0, 14)); // NOI18N
        jLabel9.setText("Address");

        gradelevel.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        gradelevel.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                gradelevelActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(28, 28, 28)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(emailaddress, javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(contactnumber, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 258, Short.MAX_VALUE)
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel1Layout.createSequentialGroup()
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                    .addComponent(jLabel3, javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel5, javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel4, javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel2, javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(studentID, javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(fname, javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(lname, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 258, Short.MAX_VALUE)
                                    .addComponent(adress, javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel6, javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel9, javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(gradelevel, javax.swing.GroupLayout.Alignment.LEADING, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                .addGap(0, 0, Short.MAX_VALUE)))
                        .addGap(15, 15, 15))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel8)
                            .addComponent(jLabel7))
                        .addGap(0, 0, Short.MAX_VALUE))))
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(87, 87, 87)
                .addComponent(add, javax.swing.GroupLayout.PREFERRED_SIZE, 123, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(25, 25, 25)
                .addComponent(jLabel3)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel2)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(studentID, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel4)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(fname, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel5)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(lname, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel6)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(gradelevel, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel7)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(emailaddress, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel8)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(contactnumber, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel9)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(adress, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(add, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jPanel4.setBackground(new java.awt.Color(153, 255, 153));

        JTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Student ID", "First Name", "Last Name", "Grade Level"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.Object.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        JTable1.setColumnSelectionAllowed(true);
        JTable1.getTableHeader().setReorderingAllowed(false);
        jScrollPane1.setViewportView(JTable1);
        JTable1.getColumnModel().getSelectionModel().setSelectionMode(javax.swing.ListSelectionModel.SINGLE_SELECTION);
        if (JTable1.getColumnModel().getColumnCount() > 0) {
            JTable1.getColumnModel().getColumn(0).setResizable(false);
            JTable1.getColumnModel().getColumn(1).setResizable(false);
            JTable1.getColumnModel().getColumn(2).setResizable(false);
            JTable1.getColumnModel().getColumn(3).setResizable(false);
        }

        jLabel1.setFont(new java.awt.Font("Segoe UI Black", 0, 36)); // NOI18N
        jLabel1.setText("STUDENTS");

        update.setBackground(new java.awt.Color(204, 204, 255));
        update.setFont(new java.awt.Font("Segoe UI Black", 1, 14)); // NOI18N
        update.setText("UPDATE");
        update.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                updateActionPerformed(evt);
            }
        });

        remove.setBackground(new java.awt.Color(255, 51, 51));
        remove.setFont(new java.awt.Font("Segoe UI Black", 1, 14)); // NOI18N
        remove.setText("ARCHIVE");
        remove.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                removeActionPerformed(evt);
            }
        });

        rewind.setBackground(new java.awt.Color(153, 255, 153));
        rewind.setForeground(new java.awt.Color(255, 255, 255));
        rewind.setIcon(new javax.swing.ImageIcon(getClass().getResource("/adminIcons/adminIcons/icons8_Exit_26px.png"))); // NOI18N
        rewind.setBorder(javax.swing.BorderFactory.createEmptyBorder(1, 1, 1, 1));
        rewind.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rewindActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel4Layout.createSequentialGroup()
                .addGap(15, 15, 15)
                .addComponent(rewind, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 188, Short.MAX_VALUE)
                .addComponent(update)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(remove)
                .addGap(12, 12, 12))
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane1)
                .addContainerGap())
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel4Layout.createSequentialGroup()
                .addContainerGap(17, Short.MAX_VALUE)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(rewind, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(remove, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(update, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jLabel1)))
                .addGap(18, 18, 18)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents
    
    
    
    private void studentIDActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_studentIDActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_studentIDActionPerformed

    private void fnameActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_fnameActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_fnameActionPerformed

    private void lnameActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_lnameActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_lnameActionPerformed

    private void updateActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_updateActionPerformed
    int selectedRow = JTable1.getSelectedRow();
    int selectedColumn = JTable1.getSelectedColumn();

    if (selectedRow == -1 || selectedColumn == -1) {
        JOptionPane.showMessageDialog(this, "Please select a cell to update.");
        return;
    }

    String columnName = JTable1.getColumnName(selectedColumn);
    String oldValue = JTable1.getValueAt(selectedRow, selectedColumn).toString();
    String studentId = JTable1.getValueAt(selectedRow, 0).toString();
    String firstName = JTable1.getValueAt(selectedRow, 1).toString();
    String lastName = JTable1.getValueAt(selectedRow, 2).toString();

    String newValue = null;

    // 🧩 Dropdown for Grade Level
    if (columnName.equals("Grade Level")) {
        String[] grades = { "Grade 7", "Grade 8", "Grade 9", "Grade 10", "Grade 11", "Grade 12" };
        newValue = (String) JOptionPane.showInputDialog(
            this,
            "Select new Grade Level:",
            "Update Grade Level",
            JOptionPane.PLAIN_MESSAGE,
            null,
            grades,
            oldValue
        );
    } else {
        newValue = JOptionPane.showInputDialog(
            this,
            "Enter new value for " + columnName + ":",
            oldValue
        );
    }

    if (newValue == null) {
        JOptionPane.showMessageDialog(this, "Update cancelled.");
        return;
    }

    newValue = newValue.trim();
    if (newValue.isEmpty()) {
        JOptionPane.showMessageDialog(this, "Value cannot be empty.");
        return;
    }

    // 🗺️ Map JTable column to SQL column
    String sqlColumn = switch (columnName) {
        case "Student ID" -> "student_id";
        case "First Name" -> "first_name";
        case "Last Name" -> "last_name";
        case "Grade Level" -> "grade_level";
        case "Contact Number" -> "contact";
        case "Email Address" -> "email_address";
        case "Address" -> "address";
        default -> null;
    };

    if (sqlColumn == null) {
        JOptionPane.showMessageDialog(this, "This column cannot be updated.");
        return;
    }

    // 🧠 Format name fields
    if (sqlColumn.equals("first_name") || sqlColumn.equals("last_name")) {
        newValue = capitalizeWords(newValue);
    }

    // ✅ Validate student_id format
    if (sqlColumn.equals("student_id") && !newValue.matches("\\d{12}")) {
        JOptionPane.showMessageDialog(this, "Student ID must be exactly 12 digits.");
        return;
    }

    // ✅ Validate contact number format
    if (sqlColumn.equals("contact") && !newValue.matches("\\d{11}")) {
        JOptionPane.showMessageDialog(this, "Contact number must be exactly 11 digits.");
        return;
    }

    // ✅ Validate email format
    if (sqlColumn.equals("email_address") && !newValue.contains("@")) {
        JOptionPane.showMessageDialog(this,
            "Invalid email address. It must contain '@'.",
            "Invalid Email",
            JOptionPane.WARNING_MESSAGE);
        return;
    }

    try (Connection con = DBConnection.getConnection()) {

        // ✅ Prevent duplicate student_id
        if (sqlColumn.equals("student_id")) {
            PreparedStatement check = con.prepareStatement("SELECT * FROM students2 WHERE student_id = ?");
            check.setString(1, newValue);
            ResultSet rs = check.executeQuery();
            if (rs.next()) {
                JOptionPane.showMessageDialog(this, "Student already registered with this ID!");
                return;
            }
        }

        // ✅ Perform the update
        String sql = "UPDATE students2 SET " + sqlColumn + " = ? WHERE student_id = ?";
        PreparedStatement ps = con.prepareStatement(sql);
        ps.setString(1, newValue);
        ps.setString(2, studentId);
        int updated = ps.executeUpdate();

        if (updated > 0) {
            JOptionPane.showMessageDialog(this, columnName + " updated successfully!");
            loadStudentsFromDatabase(); // Refresh table
        } else {
            JOptionPane.showMessageDialog(this, "Update failed. Student not found.");
        }

    } catch (SQLException e) {
        e.printStackTrace();
        JOptionPane.showMessageDialog(this, "Database error while updating student:\n" + e.getMessage());
    }
    }//GEN-LAST:event_updateActionPerformed

    private void addActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_addActionPerformed
    String id = studentID.getText().trim();
    String fName = fname.getText().trim();
    String lName = lname.getText().trim();
    String grade = (String) gradelevel.getSelectedItem();
    String email = emailaddress.getText().trim();
    String contact = contactnumber.getText().trim();
    String address = adress.getText().trim();

    // ✅ Validation
    if (id.length() != 12 || !id.matches("\\d+")) {
        JOptionPane.showMessageDialog(this, "Student ID must be exactly 12 digits.");
        return;
    }
    if (fName.isEmpty() || lName.isEmpty()) {
        JOptionPane.showMessageDialog(this, "First and Last name are required.");
        return;
    }
    if (email.isEmpty() || !email.contains("@")) {
        JOptionPane.showMessageDialog(this, "Please enter a valid email address.");
        return;
    }

    // ✅ Contact must be exactly 11 digits
    if (!contact.matches("\\d{11}")) {
        JOptionPane.showMessageDialog(this, "Contact number must be exactly 11 digits.");
        return;
    }

    if (address.isEmpty()) {
        JOptionPane.showMessageDialog(this, "Address is required.");
        return;
    }

    try (Connection con = DBConnection.getConnection()) {
        // 🔍 Check if ID already exists
        PreparedStatement check = con.prepareStatement("SELECT * FROM students2 WHERE student_id=?");
        check.setString(1, id);
        ResultSet rs = check.executeQuery();
        if (rs.next()) {
            JOptionPane.showMessageDialog(this, "Student ID already exists!");
            return;
        }

        // 🧾 Insert new student
        PreparedStatement ps = con.prepareStatement(
            "INSERT INTO students2 (student_id, first_name, last_name, grade_level, email_address, contact, address) VALUES (?, ?, ?, ?, ?, ?, ?)"
        );
        ps.setString(1, id);
        ps.setString(2, fName);
        ps.setString(3, lName);
        ps.setString(4, grade);
        ps.setString(5, email);
        ps.setString(6, contact);
        ps.setString(7, address);
        ps.executeUpdate();

        JOptionPane.showMessageDialog(this, "Student added successfully!");

        // 🔄 Refresh table
        loadStudentsFromDatabase();

        // 🧹 Clear input fields
        studentID.setText("");
        fname.setText("");
        lname.setText("");
        emailaddress.setText("");
        contactnumber.setText("");
        adress.setText("");
        gradelevel.setSelectedIndex(0);

    } catch (SQLException e) {
        e.printStackTrace();
        JOptionPane.showMessageDialog(this, "Database error while adding student:\n" + e.getMessage());
    }
    }//GEN-LAST:event_addActionPerformed

    private void removeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_removeActionPerformed
    int selectedRow = JTable1.getSelectedRow();

    if (selectedRow == -1) {
        JOptionPane.showMessageDialog(this, "Please select a student to remove.");
        return;
    }

    // Get student details
    String studentId = JTable1.getValueAt(selectedRow, 0).toString();
    String firstName = JTable1.getValueAt(selectedRow, 1).toString();
    String lastName = JTable1.getValueAt(selectedRow, 2).toString();
    String gradeLevel = JTable1.getValueAt(selectedRow, 3).toString();
    String emailAddress = JTable1.getValueAt(selectedRow, 4).toString();
    String contactNumber = JTable1.getValueAt(selectedRow, 5).toString();
    String address = JTable1.getValueAt(selectedRow, 6).toString();

    try (Connection con = DBConnection.getConnection()) {

        // 🚫 Check if the student has borrowed books
        String checkSql = "SELECT * FROM borrowed_books3 WHERE first_name = ? AND last_name = ?";
        try (PreparedStatement psCheck = con.prepareStatement(checkSql)) {
            psCheck.setString(1, firstName);
            psCheck.setString(2, lastName);
            ResultSet rs = psCheck.executeQuery();

            if (rs.next()) {
                JOptionPane.showMessageDialog(this,
                    "This student currently has borrowed books and cannot be archived! please reach out the student.",
                    "Archive Blocked",
                    JOptionPane.WARNING_MESSAGE);
                return;
            }
        }

        // Confirm archive
        int confirm = JOptionPane.showConfirmDialog(
            this,
            "Are you sure you want to remove and archive this student?",
            "Confirm Archive",
            JOptionPane.YES_NO_OPTION
        );
        if (confirm != JOptionPane.YES_OPTION) return;

        con.setAutoCommit(false); // Start transaction

        // 1️⃣ Insert into archive_students1
        String insertSql = "INSERT INTO archive_students1 "
                + "(student_id, first_name, last_name, grade_level, email_address, contact, address) "
                + "VALUES (?, ?, ?, ?, ?, ?, ?)";
        try (PreparedStatement psInsert = con.prepareStatement(insertSql)) {
            psInsert.setString(1, studentId);
            psInsert.setString(2, firstName);
            psInsert.setString(3, lastName);
            psInsert.setString(4, gradeLevel);
            psInsert.setString(5, emailAddress);
            psInsert.setString(6, contactNumber);
            psInsert.setString(7, address);
            psInsert.executeUpdate();
        }

        // 2️⃣ Delete from students2
        String deleteSql = "DELETE FROM students2 WHERE student_id = ?";
        try (PreparedStatement psDelete = con.prepareStatement(deleteSql)) {
            psDelete.setString(1, studentId);
            psDelete.executeUpdate();
        }

        con.commit();
        JOptionPane.showMessageDialog(this, "Student archived successfully!");
        loadStudentsFromDatabase();

    } catch (SQLException e) {
        e.printStackTrace();
        JOptionPane.showMessageDialog(this, "Error archiving student: " + e.getMessage());
        }
    }//GEN-LAST:event_removeActionPerformed

    private void rewindActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rewindActionPerformed
        setVisible(false);
        Home home = new Home();
        home.updateStudentCount();
        home.setVisible(true);
    }//GEN-LAST:event_rewindActionPerformed

    private void gradelevelActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_gradelevelActionPerformed
        
    }//GEN-LAST:event_gradelevelActionPerformed

    private void contactnumberActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_contactnumberActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_contactnumberActionPerformed

    private void emailaddressActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_emailaddressActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_emailaddressActionPerformed

    private void adressActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_adressActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_adressActionPerformed
    
    
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Students.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Students.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Students.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Students.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Students().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTable JTable1;
    private javax.swing.JButton add;
    private javax.swing.JTextField adress;
    private javax.swing.JTextField contactnumber;
    private javax.swing.JTextField emailaddress;
    private javax.swing.JTextField fname;
    private javax.swing.JComboBox<String> gradelevel;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextField lname;
    private javax.swing.JButton remove;
    private javax.swing.JButton rewind;
    private javax.swing.JTextField studentID;
    private javax.swing.JButton update;
    // End of variables declaration//GEN-END:variables
}
