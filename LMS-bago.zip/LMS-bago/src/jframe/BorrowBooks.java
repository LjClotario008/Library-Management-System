/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package jframe;

import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.sql.Date;
/**
 *
 * @author Admin
 */
public class BorrowBooks extends javax.swing.JFrame {
        public static int BorrowBookCount = 0;
        

    /**
     * Creates new form BorrowBooks
     */
    public BorrowBooks() {
        initComponents();
        loadStudentComboBox();
        loadBookComboBox();
        updateFines();
        addTableRightClickMenu();
        enableCellEditingWithDialog();
        loadBorrowedBooks();
    }
    private void loadBorrowedBooks() {
    DefaultTableModel model = (DefaultTableModel) jTable1.getModel();
    model.setRowCount(0);

    try (Connection con = DBConnection.getConnection()) {
        String sql = """
            SELECT s.first_name, s.last_name, b.book_title, b.category, b.quantity, b.due_date
            FROM borrowed_books3 b
            JOIN students2 s ON b.student_id = s.student_id
        """;

        PreparedStatement ps = con.prepareStatement(sql);
        ResultSet rs = ps.executeQuery();

        while (rs.next()) {
            String firstName = rs.getString("first_name");
            String lastName = rs.getString("last_name");
            String fullName = firstName + " " + lastName;
            String book = rs.getString("book_title");
            String category = rs.getString("category");
            int qty = rs.getInt("quantity");
            String dueDate = rs.getDate("due_date").toString();

            model.addRow(new Object[]{fullName, book, category, qty, dueDate});
        }

    } catch (Exception e) {
        JOptionPane.showMessageDialog(this, "Error loading borrowed books:\n" + e.getMessage());
    }
}
    private void enableCellEditingWithDialog() {
    jTable1.addMouseListener(new java.awt.event.MouseAdapter() {
        public void mouseClicked(java.awt.event.MouseEvent evt) {
            if (evt.getClickCount() == 2 && jTable1.getSelectedRow() != -1 && jTable1.getSelectedColumn() != -1) {
                int row = jTable1.getSelectedRow();
                int col = jTable1.getSelectedColumn();

                String columnName = jTable1.getColumnName(col);

                // Disable editing for Student ID, Book Title, and Category
                if (columnName.equalsIgnoreCase("Student ID") ||
                    columnName.equalsIgnoreCase("Book Title") ||
                    columnName.equalsIgnoreCase("Category")) {
                    JOptionPane.showMessageDialog(BorrowBooks.this, columnName + " cannot be edited!");
                    return;
                }

                String oldValue = jTable1.getValueAt(row, col).toString();

                String newValue = JOptionPane.showInputDialog(
                        BorrowBooks.this,
                        "Enter new value for " + columnName + ":",
                        oldValue
                );

                if (newValue == null) {
                    JOptionPane.showMessageDialog(BorrowBooks.this, "Edit cancelled.");
                    return;
                }

                newValue = newValue.trim();
                if (newValue.isEmpty()) {
                    JOptionPane.showMessageDialog(BorrowBooks.this, "Value cannot be empty!");
                    return;
                }

                // Validation
                if (columnName.equalsIgnoreCase("Quantity") && !newValue.matches("\\d+")) {
                    JOptionPane.showMessageDialog(BorrowBooks.this, "Please enter a valid quantity number!");
                    return;
                }

                if (columnName.equalsIgnoreCase("Due Date")) {
                    try {
                        java.time.LocalDate.parse(newValue);
                    } catch (Exception e) {
                        JOptionPane.showMessageDialog(BorrowBooks.this, "Please enter a valid date (YYYY-MM-DD).");
                        return;
                    }
                }

                // Get unique keys for DB update
                String studentId = jTable1.getValueAt(row, 0).toString(); // assuming column 0 = student_id
                String book = jTable1.getValueAt(row, 1).toString();

                // Map table column to DB column
                String dbColumn = switch (columnName) {
                    case "Quantity" -> "quantity";
                    case "Due Date" -> "due_date";
                    default -> null;
                };

                if (dbColumn == null) return;

                try (java.sql.Connection con = DBConnection.getConnection()) {
                    String sql = "UPDATE borrowed_books3 SET " + dbColumn + " = ? WHERE student_id = ? AND book_title = ?";
                    java.sql.PreparedStatement ps = con.prepareStatement(sql);

                    if (dbColumn.equals("due_date")) {
                        ps.setDate(1, java.sql.Date.valueOf(newValue));
                    } else if (dbColumn.equals("quantity")) {
                        ps.setInt(1, Integer.parseInt(newValue));
                    }

                    ps.setString(2, studentId);
                    ps.setString(3, book);

                    int updated = ps.executeUpdate();
                    if (updated > 0) {
                        jTable1.setValueAt(newValue, row, col);
                        JOptionPane.showMessageDialog(BorrowBooks.this, columnName + " updated successfully!");
                    } else {
                        JOptionPane.showMessageDialog(BorrowBooks.this, "Record not found or update failed.");
                    }
                } catch (Exception ex) {
                    ex.printStackTrace();
                    JOptionPane.showMessageDialog(BorrowBooks.this, "Error: " + ex.getMessage());
                }
            }
        }
    });
}
    private void addTableRightClickMenu() {
    javax.swing.JPopupMenu popupMenu = new javax.swing.JPopupMenu();
    javax.swing.JMenuItem updateItem = new javax.swing.JMenuItem("Edit / Update Record");

    updateItem.addActionListener(e -> {
        int selectedRow = jTable1.getSelectedRow();
        int selectedCol = jTable1.getSelectedColumn();

        if (selectedRow == -1 || selectedCol == -1) {
            JOptionPane.showMessageDialog(this, "Please right-click on a cell to edit.");
            return;
        }

        // Only allow editing Due Date (4) (disable Quantity (3))
        if (selectedCol != 4) {
            JOptionPane.showMessageDialog(this, "You can only edit the Due Date!");
            return;
        }

        DefaultTableModel model = (DefaultTableModel) jTable1.getModel();
        String columnName = model.getColumnName(selectedCol);
        String oldValue = model.getValueAt(selectedRow, selectedCol).toString();

        // Get student_id and book_title
        String studentId = model.getValueAt(selectedRow, 0).toString();
        String bookKey = model.getValueAt(selectedRow, 1).toString();

        try (Connection con = DBConnection.getConnection()) {

            // --- DUE DATE EDIT (JCalendar) ---
            if (selectedCol == 4) {
                com.toedter.calendar.JCalendar calendar = new com.toedter.calendar.JCalendar();

                try {
                    java.util.Date currentDate = java.sql.Date.valueOf(oldValue);
                    calendar.setDate(currentDate);
                } catch (Exception ex) {
                    calendar.setDate(new java.util.Date());
                }

                int result = JOptionPane.showConfirmDialog(
                        this,
                        calendar,
                        "Select new Due Date",
                        JOptionPane.OK_CANCEL_OPTION,
                        JOptionPane.PLAIN_MESSAGE
                );

                if (result == JOptionPane.OK_OPTION) {
                    java.util.Date selectedDate = calendar.getDate();
                    java.time.LocalDate newDueDate = selectedDate.toInstant()
                            .atZone(java.time.ZoneId.systemDefault())
                            .toLocalDate();

                    if (!newDueDate.isAfter(java.time.LocalDate.now())) {
                        JOptionPane.showMessageDialog(this, "Due date must be in the future.");
                        return;
                    }

                    // Update borrowed_books3 table using student_id and book_title
                    PreparedStatement psUpdateDate = con.prepareStatement(
                            "UPDATE borrowed_books3 SET due_date=? WHERE student_id=? AND book_title=?");
                    psUpdateDate.setDate(1, java.sql.Date.valueOf(newDueDate));
                    psUpdateDate.setString(2, studentId);
                    psUpdateDate.setString(3, bookKey);
                    psUpdateDate.executeUpdate();

                    // Update table model with the new Due Date
                    model.setValueAt(newDueDate.toString(), selectedRow, selectedCol);
                    JOptionPane.showMessageDialog(this, "Due Date updated successfully!");
                }
            }

        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Database error: " + ex.getMessage());
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage());
        }
    });

    popupMenu.add(updateItem);
    jTable1.setComponentPopupMenu(popupMenu);
}
    private String capitalizeWords(String input) {
    if (input == null || input.isEmpty()) return input;
    String[] words = input.toLowerCase().split("\\s+");
    StringBuilder sb = new StringBuilder();
    for (String word : words) {
        if (word.length() > 0) {
            sb.append(Character.toUpperCase(word.charAt(0)))
              .append(word.substring(1))
              .append(" ");
        }
    }
    return sb.toString().trim();
}
    private void updateFines() {
    try (Connection con = DBConnection.getConnection();
         PreparedStatement ps = con.prepareStatement(
             "UPDATE borrowed_books3 " +
             "SET fine = GREATEST(DATEDIFF(CURDATE(), due_date) * 15, 0) " +
             "WHERE CURDATE() > due_date")) {

        int updated = ps.executeUpdate();
        System.out.println("Fines updated for " + updated + " overdue records.");

    } catch (SQLException e) {
        JOptionPane.showMessageDialog(this, "Error updating fines:\n" + e.getMessage());
    }
}
    private void loadStudentComboBox() {
    studentborrow.removeAllItems(); // Clear existing items

    try (Connection con = DBConnection.getConnection()) {
        // Select first name and last name only
        String sql = "SELECT first_name, last_name FROM students2";
        PreparedStatement ps = con.prepareStatement(sql);
        ResultSet rs = ps.executeQuery();

        boolean hasStudents = false;

        while (rs.next()) {
            String firstName = rs.getString("first_name");
            String lastName = rs.getString("last_name");

            // Capitalize properly (first letter uppercase, rest lowercase)
            String formattedFirst = firstName.substring(0, 1).toUpperCase() + firstName.substring(1).toLowerCase();
            String formattedLast = lastName.substring(0, 1).toUpperCase() + lastName.substring(1).toLowerCase();

            String fullName = formattedFirst + " " + formattedLast;
            studentborrow.addItem(fullName);
            hasStudents = true;
        }

        if (!hasStudents) {
            studentborrow.addItem("No registered students yet");
        }

    } catch (SQLException e) {
        JOptionPane.showMessageDialog(this,
            "Error loading students:\n" + e.getMessage(),
            "Database Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    private void loadBookComboBox(){
    bookborrow.removeAllItems(); // clear current items

    try (Connection con = DBConnection.getConnection()) {
        // Select only books that are available (quantity > 0)
        String sql = "SELECT title, category, quantity FROM books1 WHERE quantity > 0";
        PreparedStatement ps = con.prepareStatement(sql);
        ResultSet rs = ps.executeQuery();

        boolean hasBooks = false;

        while (rs.next()) {
            String title = rs.getString("title");
            String category = rs.getString("category");
            int quantity = rs.getInt("quantity");

            // Capitalize each word in the title
            String formattedTitle = capitalizeWords(title);
            String formattedCategory = category.substring(0, 1).toUpperCase() + category.substring(1).toLowerCase();

            // Combine title, category, and quantity for display
            String displayText = formattedTitle + " - " + formattedCategory + " (" + quantity + ")";
            bookborrow.addItem(displayText);
            hasBooks = true;
        }

        if (!hasBooks) {
            bookborrow.addItem("No books available");
        }

    } catch (SQLException e) {
        JOptionPane.showMessageDialog(this,
            "Error loading books:\n" + e.getMessage(),
            "Database Error", JOptionPane.ERROR_MESSAGE);
            }
        
    }
    
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        add = new javax.swing.JButton();
        studentborrow = new javax.swing.JComboBox<>();
        bookborrow = new javax.swing.JComboBox<>();
        txtquantity = new javax.swing.JTextField();
        dueDateChooser = new com.toedter.calendar.JDateChooser();
        jPanel4 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jLabel1 = new javax.swing.JLabel();
        update = new javax.swing.JButton();
        remove = new javax.swing.JButton();
        rewind = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(153, 153, 153));

        jLabel2.setFont(new java.awt.Font("Segoe UI Black", 0, 14)); // NOI18N
        jLabel2.setText("Student");

        jLabel3.setFont(new java.awt.Font("Segoe UI Black", 0, 24)); // NOI18N
        jLabel3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/AddNewBookIcons/AddNewBookIcons/icons8_Book_50px_1.png"))); // NOI18N
        jLabel3.setText("BORROW BOOK");

        jLabel4.setFont(new java.awt.Font("Segoe UI Black", 0, 14)); // NOI18N
        jLabel4.setText("Book");

        jLabel5.setFont(new java.awt.Font("Segoe UI Black", 0, 14)); // NOI18N
        jLabel5.setText("Quantity");

        jLabel6.setFont(new java.awt.Font("Segoe UI Black", 0, 14)); // NOI18N
        jLabel6.setText("Due Date");

        add.setFont(new java.awt.Font("Segoe UI Black", 1, 14)); // NOI18N
        add.setText("BORROW");
        add.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                addActionPerformed(evt);
            }
        });

        studentborrow.setModel(new javax.swing.DefaultComboBoxModel<>());

        bookborrow.setModel(new javax.swing.DefaultComboBoxModel<>());
        bookborrow.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                bookborrowActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap(31, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addComponent(add, javax.swing.GroupLayout.PREFERRED_SIZE, 123, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(89, 89, 89))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel6)
                            .addComponent(jLabel5)
                            .addComponent(jLabel4)
                            .addComponent(jLabel2)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(8, 8, 8)
                                .addComponent(jLabel3))
                            .addComponent(studentborrow, javax.swing.GroupLayout.PREFERRED_SIZE, 239, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                .addComponent(dueDateChooser, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(txtquantity, javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(bookborrow, javax.swing.GroupLayout.Alignment.LEADING, 0, 239, Short.MAX_VALUE)))
                        .addGap(34, 34, 34))))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel3)
                .addGap(26, 26, 26)
                .addComponent(jLabel2)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(studentborrow, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jLabel4)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(bookborrow, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jLabel5)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(txtquantity, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(12, 12, 12)
                .addComponent(jLabel6)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(dueDateChooser, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(42, 42, 42)
                .addComponent(add, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(46, 46, 46))
        );

        jPanel4.setBackground(new java.awt.Color(153, 255, 153));

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Student", "Book Title", "Category", "Quantity", "Due Date"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jTable1.setColumnSelectionAllowed(true);
        jScrollPane1.setViewportView(jTable1);
        jTable1.getColumnModel().getSelectionModel().setSelectionMode(javax.swing.ListSelectionModel.SINGLE_SELECTION);
        if (jTable1.getColumnModel().getColumnCount() > 0) {
            jTable1.getColumnModel().getColumn(0).setResizable(false);
            jTable1.getColumnModel().getColumn(0).setHeaderValue("Student");
            jTable1.getColumnModel().getColumn(1).setResizable(false);
            jTable1.getColumnModel().getColumn(1).setHeaderValue("Book Title");
            jTable1.getColumnModel().getColumn(2).setResizable(false);
            jTable1.getColumnModel().getColumn(2).setHeaderValue("Category");
            jTable1.getColumnModel().getColumn(3).setResizable(false);
            jTable1.getColumnModel().getColumn(3).setHeaderValue("Quantity");
            jTable1.getColumnModel().getColumn(4).setResizable(false);
            jTable1.getColumnModel().getColumn(4).setHeaderValue("Due Date");
        }

        jLabel1.setFont(new java.awt.Font("Segoe UI Black", 0, 36)); // NOI18N
        jLabel1.setText("BORROW");

        update.setBackground(new java.awt.Color(204, 204, 255));
        update.setFont(new java.awt.Font("Segoe UI Black", 1, 14)); // NOI18N
        update.setText("UPDATE");
        update.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                updateActionPerformed(evt);
            }
        });

        remove.setBackground(new java.awt.Color(255, 51, 51));
        remove.setFont(new java.awt.Font("Segoe UI Black", 1, 14)); // NOI18N
        remove.setText("REMOVE");
        remove.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                removeActionPerformed(evt);
            }
        });

        rewind.setBackground(new java.awt.Color(153, 255, 153));
        rewind.setForeground(new java.awt.Color(255, 255, 255));
        rewind.setIcon(new javax.swing.ImageIcon(getClass().getResource("/adminIcons/adminIcons/icons8_Exit_26px.png"))); // NOI18N
        rewind.setBorder(null);
        rewind.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rewindActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 560, Short.MAX_VALUE))
                    .addGroup(jPanel4Layout.createSequentialGroup()
                        .addGap(20, 20, 20)
                        .addComponent(rewind, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jLabel1)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(update)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(remove)
                        .addGap(6, 6, 6)))
                .addContainerGap())
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel4Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(remove, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(update, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jLabel1))
                    .addComponent(rewind, javax.swing.GroupLayout.PREFERRED_SIZE, 51, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void addActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_addActionPerformed
    String selectedStudent = (String) studentborrow.getSelectedItem();
    String selectedBook = (String) bookborrow.getSelectedItem();
    String book = selectedBook != null && selectedBook.contains(" - ")
            ? selectedBook.split(" - ")[0]
            : selectedBook;
    String qtyText = txtquantity.getText().trim();

    // Validate student and book selection
    if (selectedStudent == null || selectedStudent.isEmpty() || book == null || book.isEmpty()) {
        JOptionPane.showMessageDialog(this, "Please select both a student and a book.");
        return;
    }

    // Validate quantity
    int qty;
    try {
        qty = Integer.parseInt(qtyText);
        if (qty <= 0) throw new NumberFormatException();
    } catch (NumberFormatException e) {
        JOptionPane.showMessageDialog(this, "Enter a valid positive quantity!");
        return;
    }

    // Limit to 1 copy per book
    if (qty > 1) {
        JOptionPane.showMessageDialog(this,
                "You can only borrow 1 copy per book.",
                "Borrow Limit",
                JOptionPane.WARNING_MESSAGE);
        return;
    }

    // Validate due date
    java.util.Date selectedDate = dueDateChooser.getDate();
    if (selectedDate == null) {
        JOptionPane.showMessageDialog(this, "Please select a due date.");
        return;
    }

    LocalDate dueDate = selectedDate.toInstant()
            .atZone(java.time.ZoneId.systemDefault())
            .toLocalDate();
    if (!dueDate.isAfter(LocalDate.now())) {
        JOptionPane.showMessageDialog(this, "Due date must be in the future.");
        return;
    }

    try (Connection con = DBConnection.getConnection()) {

        // Get student_id (as String), first_name, last_name from students2
        String[] nameParts = selectedStudent.split(" ");
        String firstName = nameParts[0];
        String lastName = nameParts.length > 1 ? nameParts[1] : "";

        PreparedStatement psFindId = con.prepareStatement(
                "SELECT student_id, first_name, last_name FROM students2 WHERE first_name = ? AND last_name = ?");
        psFindId.setString(1, firstName);
        psFindId.setString(2, lastName);
        ResultSet rsId = psFindId.executeQuery();

        if (!rsId.next()) {
            JOptionPane.showMessageDialog(this, "Student not found in the system!");
            return;
        }

        String studentId = rsId.getString("student_id");
        String dbFirstName = rsId.getString("first_name");
        String dbLastName = rsId.getString("last_name");

        // ✅ Prevent borrowing same book twice
        PreparedStatement psCheckDuplicate = con.prepareStatement(
                "SELECT * FROM borrowed_books3 WHERE student_id = ? AND book_title = ?");
        psCheckDuplicate.setString(1, studentId);
        psCheckDuplicate.setString(2, book);
        ResultSet rsDup = psCheckDuplicate.executeQuery();

        if (rsDup.next()) {
            JOptionPane.showMessageDialog(this,
                    "This student already borrowed this book!",
                    "Duplicate Borrow",
                    JOptionPane.WARNING_MESSAGE);
            return;
        }

        // Limit total borrowed books to 3
        PreparedStatement psCount = con.prepareStatement(
                "SELECT COUNT(*) AS total FROM borrowed_books3 WHERE student_id = ?");
        psCount.setString(1, studentId);
        ResultSet rsCount = psCount.executeQuery();

        if (rsCount.next()) {
            int borrowedCount = rsCount.getInt("total");
            if (borrowedCount >= 3) {
                JOptionPane.showMessageDialog(this,
                        "You cannot borrow more than 3 books in total!",
                        "Borrow Limit Reached",
                        JOptionPane.WARNING_MESSAGE);
                return;
            }
        }

        // Check book stock
        PreparedStatement psCheck = con.prepareStatement(
                "SELECT quantity, category FROM books1 WHERE title = ?");
        psCheck.setString(1, book);
        ResultSet rs = psCheck.executeQuery();

        if (!rs.next()) {
            JOptionPane.showMessageDialog(this, "Book not found in the system!");
            return;
        }

        int available = rs.getInt("quantity");
        String category = rs.getString("category");

        if (qty > available) {
            JOptionPane.showMessageDialog(this, "Not enough stock available!");
            return;
        }

        // Deduct stock
        PreparedStatement psUpdate = con.prepareStatement(
                "UPDATE books1 SET quantity = quantity - ? WHERE title = ?");
        psUpdate.setInt(1, qty);
        psUpdate.setString(2, book);
        psUpdate.executeUpdate();

        // Insert borrowed record
        PreparedStatement psInsert = con.prepareStatement(
                "INSERT INTO borrowed_books3 (student_id, first_name, last_name, book_title, category, quantity, borrow_date, due_date, fine) " +
                        "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)");
        psInsert.setString(1, studentId);
        psInsert.setString(2, dbFirstName);
        psInsert.setString(3, dbLastName);
        psInsert.setString(4, book);
        psInsert.setString(5, category);
        psInsert.setInt(6, qty);
        psInsert.setDate(7, Date.valueOf(LocalDate.now()));
        psInsert.setDate(8, Date.valueOf(dueDate));
        psInsert.setDouble(9, 0.00);
        psInsert.executeUpdate();

        // Update JTable view
        DefaultTableModel model = (DefaultTableModel) jTable1.getModel();
        String fullName = dbFirstName + " " + dbLastName;
        model.addRow(new Object[]{fullName, book, category, qty, dueDate.toString(), "₱0.00"});

        JOptionPane.showMessageDialog(this, "Book borrowed successfully!");
        txtquantity.setText("");
        loadBookComboBox();

    } catch (SQLException e) {
        JOptionPane.showMessageDialog(this, "Error borrowing book: " + e.getMessage());
        e.printStackTrace();
}       
    }//GEN-LAST:event_addActionPerformed

    private void updateActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_updateActionPerformed
    int selectedRow = jTable1.getSelectedRow();
    int selectedColumn = jTable1.getSelectedColumn();

    if (selectedRow == -1 || selectedColumn == -1) {
        JOptionPane.showMessageDialog(this, "Please select a cell to update!");
        return;
    }

    DefaultTableModel model = (DefaultTableModel) jTable1.getModel();
    String columnName = model.getColumnName(selectedColumn);

    // ✅ Only allow updating the Due Date — disable Quantity
    if (!columnName.equalsIgnoreCase("Due Date")) {
        JOptionPane.showMessageDialog(this, "You can only update the Due Date!");
        return;
    }

    // Get student full name and book title
    String studentName = model.getValueAt(selectedRow, 0).toString(); // first + last name
    String bookKey = model.getValueAt(selectedRow, 1).toString();
    String oldValue = model.getValueAt(selectedRow, selectedColumn).toString();

    try (Connection con = DBConnection.getConnection()) {

        // Get student_id from students2 using first_name + last_name
        String[] nameParts = studentName.split(" ");
        String firstName = nameParts[0];
        String lastName = nameParts.length > 1 ? nameParts[1] : "";

        PreparedStatement psFind = con.prepareStatement(
            "SELECT student_id FROM students2 WHERE first_name = ? AND last_name = ?"
        );
        psFind.setString(1, firstName);
        psFind.setString(2, lastName);
        ResultSet rsFind = psFind.executeQuery();

        if (!rsFind.next()) {
            JOptionPane.showMessageDialog(this, "Student not found in the system!");
            return;
        }

        String studentId = rsFind.getString("student_id");

        // --- Only Update Due Date ---
        com.toedter.calendar.JCalendar calendar = new com.toedter.calendar.JCalendar();

        // Preselect current due date
        try {
            java.util.Date oldDate = java.sql.Date.valueOf(oldValue);
            calendar.setDate(oldDate);
        } catch (Exception ignored) {}

        javax.swing.JPanel panel = new javax.swing.JPanel();
        panel.add(calendar);

        int option = JOptionPane.showConfirmDialog(
            this,
            panel,
            "Select new Due Date",
            JOptionPane.OK_CANCEL_OPTION,
            JOptionPane.PLAIN_MESSAGE
        );

        if (option == JOptionPane.OK_OPTION) {
            java.util.Date selectedDate = calendar.getDate();
            if (selectedDate == null) {
                JOptionPane.showMessageDialog(this, "Please select a valid date!");
                return;
            }

            java.sql.Date sqlDate = new java.sql.Date(selectedDate.getTime());
            LocalDate dueDate = sqlDate.toLocalDate();

            if (!dueDate.isAfter(LocalDate.now())) {
                JOptionPane.showMessageDialog(this, "Due date must be in the future.");
                return;
            }

            PreparedStatement psUpdateDate = con.prepareStatement(
                "UPDATE borrowed_books3 SET due_date = ? WHERE student_id = ? AND book_title = ?"
            );
            psUpdateDate.setDate(1, sqlDate);
            psUpdateDate.setString(2, studentId);
            psUpdateDate.setString(3, bookKey);
            psUpdateDate.executeUpdate();

            model.setValueAt(sqlDate.toString(), selectedRow, selectedColumn);
            JOptionPane.showMessageDialog(this, "Due Date updated successfully!");
        }

    } catch (SQLException ex) {
        JOptionPane.showMessageDialog(this, "Database error: " + ex.getMessage());
    } catch (NumberFormatException e) {
        JOptionPane.showMessageDialog(this, "Invalid number format!");
        }
    
    }//GEN-LAST:event_updateActionPerformed

    private void removeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_removeActionPerformed
    DefaultTableModel model = (DefaultTableModel) jTable1.getModel();
    int selectedRow = jTable1.getSelectedRow();
    if (selectedRow == -1) {
        JOptionPane.showMessageDialog(this, "Please select a record to archive!");
        return;
    }

    String fullName = jTable1.getValueAt(selectedRow, 0).toString(); // student full name
    String book = jTable1.getValueAt(selectedRow, 1).toString();      // book title
    int qty = Integer.parseInt(jTable1.getValueAt(selectedRow, 3).toString());

    int confirm = JOptionPane.showConfirmDialog(this,
        "Are you sure you want to archive this record?\nThe quantity will be restored.",
        "Confirm Archive", JOptionPane.YES_NO_OPTION);
    if (confirm != JOptionPane.YES_OPTION) return;

    try (Connection con = DBConnection.getConnection()) {
        // --- Get student_id from students2 ---
        String[] nameParts = fullName.split(" ");
        String firstName = nameParts[0];
        String lastName = nameParts.length > 1 ? nameParts[1] : "";

        PreparedStatement psFind = con.prepareStatement(
            "SELECT student_id FROM students2 WHERE first_name = ? AND last_name = ?"
        );
        psFind.setString(1, firstName);
        psFind.setString(2, lastName);
        ResultSet rs = psFind.executeQuery();

        if (!rs.next()) {
            JOptionPane.showMessageDialog(this, "Student not found in the system!");
            return;
        }

        String studentId = rs.getString("student_id");

        // --- Delete record from borrowed_books3 ---
        PreparedStatement psDelete = con.prepareStatement(
            "DELETE FROM borrowed_books3 WHERE student_id = ? AND book_title = ?"
        );
        psDelete.setString(1, studentId);
        psDelete.setString(2, book);
        psDelete.executeUpdate();

        // --- Restore stock in books1 ---
        PreparedStatement psUpdateStock = con.prepareStatement(
            "UPDATE books1 SET quantity = quantity + ? WHERE title = ?"
        );
        psUpdateStock.setInt(1, qty);
        psUpdateStock.setString(2, book);
        psUpdateStock.executeUpdate();

        // --- Remove row from JTable ---
        model.removeRow(selectedRow);

        JOptionPane.showMessageDialog(this, "Stock restored successfully!");
        loadBookComboBox(); // refresh available books

    } catch (SQLException e) {
        JOptionPane.showMessageDialog(this,
            "Error while removing record:\n" + e.getMessage(),
            "Database Error", JOptionPane.ERROR_MESSAGE);
        e.printStackTrace();
        }
    }//GEN-LAST:event_removeActionPerformed

    private void rewindActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rewindActionPerformed
        setVisible(false);
        new Home().setVisible(true);
    }//GEN-LAST:event_rewindActionPerformed

    private void bookborrowActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_bookborrowActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_bookborrowActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(BorrowBooks.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(BorrowBooks.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(BorrowBooks.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(BorrowBooks.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new BorrowBooks().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton add;
    private javax.swing.JComboBox<String> bookborrow;
    private com.toedter.calendar.JDateChooser dueDateChooser;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JScrollPane jScrollPane1;
    public static javax.swing.JTable jTable1;
    private javax.swing.JButton remove;
    private javax.swing.JButton rewind;
    private javax.swing.JComboBox<String> studentborrow;
    private javax.swing.JTextField txtquantity;
    private javax.swing.JButton update;
    // End of variables declaration//GEN-END:variables
}

