/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package jframe;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
/**
 *
 * @author Admin
 */
public class History extends javax.swing.JFrame {

    /**
     * Creates new form History
     */
    public History() {
        initComponents();
        loadReturnHistory();
        styleTable();
        addRightClickMenu();
    }
    private void addRightClickMenu() {
    javax.swing.JPopupMenu popupMenu = new javax.swing.JPopupMenu();

    // View Return Details
    javax.swing.JMenuItem openDetails = new javax.swing.JMenuItem("View Return Details");
    openDetails.addActionListener(e -> {
        int selectedRow = tablehistory.getSelectedRow();
        if (selectedRow != -1) {
            String fullName = tablehistory.getValueAt(selectedRow, 0).toString();
            History_Return historyReturn = new History_Return(fullName);
            historyReturn.setVisible(true);
            this.dispose();
        } else {
            javax.swing.JOptionPane.showMessageDialog(this, "Please select a row first.");
        }
    });

    // ✅ Remove Selected Row
    javax.swing.JMenuItem removeRow = new javax.swing.JMenuItem("Remove Selected Record");
    removeRow.addActionListener(e -> {
        int selectedRow = tablehistory.getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(this, "Please select a row to remove.");
            return;
        }

        String fullName = tablehistory.getValueAt(selectedRow, 0).toString();
        int confirm = JOptionPane.showConfirmDialog(
            this,
            "Are you sure you want to remove all records for " + fullName + "?",
            "Confirm Deletion",
            JOptionPane.YES_NO_OPTION
        );

        if (confirm == JOptionPane.YES_OPTION) {
            try (Connection con = DBConnection.getConnection()) {
                String sql = """
                    DELETE FROM ret_books1 
                    WHERE CONCAT(UPPER(first_name), ' ', UPPER(last_name)) = ?
                """;
                PreparedStatement ps = con.prepareStatement(sql);
                ps.setString(1, fullName);
                int rowsDeleted = ps.executeUpdate();

                if (rowsDeleted > 0) {
                    ((javax.swing.table.DefaultTableModel) tablehistory.getModel()).removeRow(selectedRow);
                    JOptionPane.showMessageDialog(this, fullName + " has been removed from the history.");
                } else {
                    JOptionPane.showMessageDialog(this, "No records found for " + fullName + ".");
                }

            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, "Error removing record: " + ex.getMessage());
                ex.printStackTrace();
            }
        }
    });

    // Add both options to popup menu
    popupMenu.add(openDetails);
    popupMenu.add(removeRow);

    // Attach to table
    tablehistory.setComponentPopupMenu(popupMenu);
}
    private void styleTable() {
    // Make table text centered and bold (same style as Home.java)
    javax.swing.table.JTableHeader header = tablehistory.getTableHeader();
    javax.swing.table.DefaultTableCellRenderer headerRenderer =
        (javax.swing.table.DefaultTableCellRenderer) header.getDefaultRenderer();
    headerRenderer.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
    header.setFont(new java.awt.Font("Segoe UI", java.awt.Font.BOLD, 14));

    javax.swing.table.DefaultTableCellRenderer centerRenderer = new javax.swing.table.DefaultTableCellRenderer();
    centerRenderer.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
    centerRenderer.setFont(new java.awt.Font("Segoe UI", java.awt.Font.BOLD, 13));

    for (int i = 0; i < tablehistory.getColumnCount(); i++) {
        tablehistory.getColumnModel().getColumn(i).setCellRenderer(centerRenderer);
    }

    tablehistory.setRowHeight(30);
    tablehistory.setFont(new java.awt.Font("Segoe UI", java.awt.Font.BOLD, 13));
}
    private void loadReturnHistory() {
    DefaultTableModel model = (DefaultTableModel) tablehistory.getModel();
    model.setRowCount(0); // Clear existing rows

    try (Connection con = DBConnection.getConnection()) {
        String sql = """
            SELECT 
                CONCAT(UPPER(first_name), ' ', UPPER(last_name)) AS full_name,
                SUM(quantity) AS total_books_returned,
                SUM(fine) AS total_fines
            FROM ret_books1
            GROUP BY first_name, last_name
            ORDER BY full_name;
        """;

        PreparedStatement ps = con.prepareStatement(sql);
        ResultSet rs = ps.executeQuery();

        while (rs.next()) {
            String fullName = rs.getString("full_name");
            int totalBooks = rs.getInt("total_books_returned");
            double totalFines = rs.getDouble("total_fines");
            

            // Add the row with the latest return date
            model.addRow(new Object[]{
                fullName, 
                totalBooks, 
                String.format("%.2f", totalFines), 
            
            });
        }

    } catch (Exception e) {
        JOptionPane.showMessageDialog(this, "Error loading return history: " + e.getMessage());
        e.printStackTrace();
        }
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        rewind = new javax.swing.JButton();
        rewind1 = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        rewind2 = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        jTextField1 = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();
        jPanel4 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tablehistory = new javax.swing.JTable();

        rewind.setBackground(new java.awt.Color(153, 255, 153));
        rewind.setForeground(new java.awt.Color(255, 255, 255));
        rewind.setIcon(new javax.swing.ImageIcon(getClass().getResource("/AddNewBookIcons/AddNewBookIcons/icons8_Rewind_48px.png"))); // NOI18N
        rewind.setBorder(null);
        rewind.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rewindActionPerformed(evt);
            }
        });

        rewind1.setBackground(new java.awt.Color(153, 255, 153));
        rewind1.setForeground(new java.awt.Color(255, 255, 255));
        rewind1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/AddNewBookIcons/AddNewBookIcons/icons8_Rewind_48px.png"))); // NOI18N
        rewind1.setBorder(null);
        rewind1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rewind1ActionPerformed(evt);
            }
        });

        jLabel1.setFont(new java.awt.Font("Segoe UI Black", 0, 36)); // NOI18N
        jLabel1.setText("RETURN");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(102, 255, 153));

        rewind2.setBackground(new java.awt.Color(102, 255, 153));
        rewind2.setForeground(new java.awt.Color(255, 255, 255));
        rewind2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/adminIcons/adminIcons/icons8_Exit_26px.png"))); // NOI18N
        rewind2.setBorder(null);
        rewind2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rewind2ActionPerformed(evt);
            }
        });

        jLabel2.setFont(new java.awt.Font("Segoe UI Black", 0, 36)); // NOI18N
        jLabel2.setText("HISTORY");

        jTextField1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField1ActionPerformed(evt);
            }
        });

        jLabel3.setFont(new java.awt.Font("Segoe UI Black", 0, 14)); // NOI18N
        jLabel3.setText("Search:");

        jButton1.setFont(new java.awt.Font("Segoe UI Black", 0, 14)); // NOI18N
        jButton1.setText("Search");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(17, 17, 17)
                        .addComponent(rewind2, javax.swing.GroupLayout.PREFERRED_SIZE, 44, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(216, 216, 216)
                        .addComponent(jLabel2))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(161, 161, 161)
                        .addComponent(jLabel3)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, 199, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(82, 82, 82)
                        .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 118, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(171, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(14, 14, 14)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel2)
                    .addComponent(rewind2))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 38, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel3)
                    .addComponent(jButton1))
                .addGap(21, 21, 21))
        );

        jPanel4.setBackground(new java.awt.Color(0, 204, 51));

        tablehistory.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null}
            },
            new String [] {
                "Full Name", "Total Quantities Returned", "Total Fines"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane1.setViewportView(tablehistory);
        if (tablehistory.getColumnModel().getColumnCount() > 0) {
            tablehistory.getColumnModel().getColumn(0).setResizable(false);
            tablehistory.getColumnModel().getColumn(1).setResizable(false);
            tablehistory.getColumnModel().getColumn(2).setResizable(false);
        }

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 788, Short.MAX_VALUE)
            .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jPanel4Layout.createSequentialGroup()
                    .addContainerGap()
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 776, Short.MAX_VALUE)
                    .addContainerGap()))
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 441, Short.MAX_VALUE)
            .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jPanel4Layout.createSequentialGroup()
                    .addGap(8, 8, 8)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addContainerGap(8, Short.MAX_VALUE)))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jPanel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void rewindActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rewindActionPerformed
        setVisible(false);
        new Home().setVisible(true);
    }//GEN-LAST:event_rewindActionPerformed

    private void rewind1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rewind1ActionPerformed
        setVisible(false);
        new Home().setVisible(true);
    }//GEN-LAST:event_rewind1ActionPerformed

    private void rewind2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rewind2ActionPerformed
        setVisible(false);
        new Home().setVisible(true);
    }//GEN-LAST:event_rewind2ActionPerformed

    private void jTextField1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField1ActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        String searchText = jTextField1.getText().trim().toUpperCase();
    DefaultTableModel model = (DefaultTableModel) tablehistory.getModel();

    if (searchText.isEmpty()) {
        loadReturnHistory();
        return;
    }

    DefaultTableModel newModel = new DefaultTableModel(
        new Object[]{"Full Name", "Total Quantities Returned", "Total Fines"}, 0
    ) {
        @Override
        public boolean isCellEditable(int row, int column) {
            return false;
        }
    };

    // Separate lists for matches and non-matches
    java.util.List<Object[]> matches = new java.util.ArrayList<>();
    java.util.List<Object[]> others = new java.util.ArrayList<>();

    for (int i = 0; i < model.getRowCount(); i++) {
        String fullName = model.getValueAt(i, 0).toString().toUpperCase();
        Object[] row = {
            model.getValueAt(i, 0),
            model.getValueAt(i, 1),
            model.getValueAt(i, 2)
        };

        if (fullName.contains(searchText)) {
            matches.add(row);
        } else {
            others.add(row);
        }
    }

    // Combine matches first, then others
    for (Object[] r : matches) newModel.addRow(r);
    for (Object[] r : others) newModel.addRow(r);

    // Apply new model to the table
    tablehistory.setModel(newModel);
    styleTable();

    if (matches.isEmpty()) {
        JOptionPane.showMessageDialog(this, "No student found matching \"" + searchText + "\".");
    }
    }//GEN-LAST:event_jButton1ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(History.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(History.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(History.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(History.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new History().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextField jTextField1;
    private javax.swing.JButton rewind;
    private javax.swing.JButton rewind1;
    private javax.swing.JButton rewind2;
    private javax.swing.JTable tablehistory;
    // End of variables declaration//GEN-END:variables
}
