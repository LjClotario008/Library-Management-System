/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package jframe;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.swing.table.DefaultTableModel;
import javax.swing.JOptionPane;
import java.util.logging.Logger;

/**
 *
 * @author Usert
 */
public class History_Return extends javax.swing.JFrame {
    private static final Logger logger = Logger.getLogger(History_Return.class.getName());
    private String selectedStudent;
    /**
     * Creates new form History_Return
     */
    public History_Return(String fullName) {
        initComponents();
        this.selectedStudent = fullName;
        StudentName.setText(fullName.toUpperCase() + " - RETURN HISTORY");
        styleTable();
        loadReturnedBooksForStudent(fullName);

    }
    public History_Return() {
        initComponents();
        styleTable();
        loadAllReturnedBooks();
    }
    private void loadAllReturnedBooks() {
    DefaultTableModel model = (DefaultTableModel) studentTable.getModel();
    model.setRowCount(0);

    String sql = "SELECT UPPER(book_title) AS book_title, quantity, fine, return_date FROM ret_books1";

    try (Connection con = DBConnection.getConnection();
         PreparedStatement ps = con.prepareStatement(sql);
         ResultSet rs = ps.executeQuery()) {

        while (rs.next()) {
            String title = rs.getString("book_title").toUpperCase();
            int qty = rs.getInt("quantity");
            double fine = rs.getDouble("fine");
            String returnDate = rs.getString("return_date"); // Get the return date

            // Add the row with return date
            model.addRow(new Object[]{
                title,
                qty,
                String.format("%.2f", fine),
                returnDate // Add the return date column
            });
        }

        if (model.getRowCount() == 0) {
            JOptionPane.showMessageDialog(this, "No return records found.");
        }

    } catch (Exception e) {
        JOptionPane.showMessageDialog(this, "Error loading data: " + e.getMessage());
        e.printStackTrace();
        }
    }
        private void loadReturnedBooksForStudent(String fullName) {
        DefaultTableModel model = (DefaultTableModel) studentTable.getModel();
    model.setRowCount(0);

    String[] parts = fullName.split(" ", 2);
    String firstName = parts.length > 0 ? parts[0] : "";
    String lastName = parts.length > 1 ? parts[1] : "";

    String sql = "SELECT UPPER(book_title) AS book_title, quantity, fine, return_date "
               + "FROM ret_books1 "
               + "WHERE UPPER(first_name) = ? AND UPPER(last_name) = ?";

    try (Connection con = DBConnection.getConnection();
         PreparedStatement ps = con.prepareStatement(sql)) {

        ps.setString(1, firstName.toUpperCase());
        ps.setString(2, lastName.toUpperCase());
        ResultSet rs = ps.executeQuery();

        while (rs.next()) {
            String title = rs.getString("book_title").toUpperCase();
            int qty = rs.getInt("quantity");
            double fine = rs.getDouble("fine");
            String returnDate = rs.getString("return_date"); // Get the return date

            // Add the row with return date
            model.addRow(new Object[]{
                title,
                qty,
                String.format("%.2f", fine),
                returnDate // Add the return date column
            });
        }

        if (model.getRowCount() == 0) {
            JOptionPane.showMessageDialog(this, "No return records found for " + fullName + ".");
        }

    } catch (Exception e) {
        JOptionPane.showMessageDialog(this, "Error loading data: " + e.getMessage());
        e.printStackTrace();
        }
    }
    
    private void styleTable() {
    javax.swing.table.JTableHeader header = studentTable.getTableHeader();
    javax.swing.table.DefaultTableCellRenderer headerRenderer =
        (javax.swing.table.DefaultTableCellRenderer) header.getDefaultRenderer();
    headerRenderer.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
    header.setFont(new java.awt.Font("Segoe UI", java.awt.Font.BOLD, 14));

    javax.swing.table.DefaultTableCellRenderer centerRenderer = new javax.swing.table.DefaultTableCellRenderer();
    centerRenderer.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
    centerRenderer.setFont(new java.awt.Font("Segoe UI", java.awt.Font.BOLD, 13));

    for (int i = 0; i < studentTable.getColumnCount(); i++) {
        studentTable.getColumnModel().getColumn(i).setCellRenderer(centerRenderer);
    }

    studentTable.setRowHeight(30);
    studentTable.setFont(new java.awt.Font("Segoe UI", java.awt.Font.BOLD, 13));
}
    
    

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel4 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        studentTable = new javax.swing.JTable();
        jPanel2 = new javax.swing.JPanel();
        rewind2 = new javax.swing.JButton();
        StudentName = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel4.setBackground(new java.awt.Color(0, 204, 51));

        studentTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Book Title", "Quantity", "Fines", "Return Date"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.Integer.class, java.lang.Integer.class, java.lang.Object.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        studentTable.setColumnSelectionAllowed(true);
        studentTable.getTableHeader().setReorderingAllowed(false);
        jScrollPane1.setViewportView(studentTable);
        studentTable.getColumnModel().getSelectionModel().setSelectionMode(javax.swing.ListSelectionModel.SINGLE_INTERVAL_SELECTION);
        if (studentTable.getColumnModel().getColumnCount() > 0) {
            studentTable.getColumnModel().getColumn(0).setResizable(false);
            studentTable.getColumnModel().getColumn(1).setResizable(false);
            studentTable.getColumnModel().getColumn(2).setResizable(false);
            studentTable.getColumnModel().getColumn(3).setResizable(false);
        }

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
            .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jPanel4Layout.createSequentialGroup()
                    .addContainerGap()
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 776, Short.MAX_VALUE)
                    .addContainerGap()))
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 441, Short.MAX_VALUE)
            .addGroup(jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jPanel4Layout.createSequentialGroup()
                    .addGap(8, 8, 8)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addContainerGap(8, Short.MAX_VALUE)))
        );

        jPanel2.setBackground(new java.awt.Color(102, 255, 153));

        rewind2.setBackground(new java.awt.Color(102, 255, 153));
        rewind2.setForeground(new java.awt.Color(255, 255, 255));
        rewind2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/adminIcons/adminIcons/icons8_Exit_26px.png"))); // NOI18N
        rewind2.setBorder(null);
        rewind2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rewind2ActionPerformed(evt);
            }
        });

        StudentName.setFont(new java.awt.Font("Segoe UI Black", 0, 36)); // NOI18N
        StudentName.setText("ARCHIVE STUDENTS");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(23, 23, 23)
                .addComponent(rewind2, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(38, 38, 38)
                .addComponent(StudentName)
                .addContainerGap(319, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(StudentName))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(14, 14, 14)
                        .addComponent(rewind2, javax.swing.GroupLayout.DEFAULT_SIZE, 56, Short.MAX_VALUE)))
                .addGap(110, 110, 110))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jPanel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addContainerGap())))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void rewind2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rewind2ActionPerformed
        setVisible(false);
        new History().setVisible(true);
    }//GEN-LAST:event_rewind2ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ReflectiveOperationException | javax.swing.UnsupportedLookAndFeelException ex) {
            logger.log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(() -> new History_Return().setVisible(true));
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel StudentName;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JButton rewind2;
    private javax.swing.JTable studentTable;
    // End of variables declaration//GEN-END:variables
}
